-- Align seeded public copy with the live clinic website.
update testimonials set author = 'Google review' where id in ('seed-rev-1', 'seed-rev-2', 'seed-rev-3');

update faqs set
  question = 'Do I need an appointment to visit?',
  answer = 'Clinic visits (antenatal, postnatal, scans, child welfare) are best booked so that you are seen with less waiting. If you are in labour, come directly to the centre or call 0794 444 141 on the way. The centre does not close at night.'
where id = 'seed-faq-1';

update faqs set
  question = 'What should I bring for delivery?',
  answer = 'Bring your national ID, antenatal booklet, SHA or insurance details, clothes for yourself and the baby, sanitary pads and toiletries. If something is forgotten, the staff will help. Arriving safely is more important than a complete bag.'
where id = 'seed-faq-2';

update faqs set
  question = 'May my husband or a relative stay during labour?',
  answer = 'Yes. One birth companion may stay with you. Tell the midwife on admission.'
where id = 'seed-faq-3';

update faqs set
  question = 'Do you accept SHA, SHIF or private insurance?',
  answer = 'SHA, SHIF and selected private covers are accepted. Telephone 0794 444 141 before admission so we can confirm what your policy pays and what you will settle yourself.'
where id = 'seed-faq-4';

update faqs set
  question = 'What happens if I need a caesarean section?',
  answer = 'Emergency caesarean section is not performed at this centre. If labour requires theatre or specialist obstetric care, the woman is stabilised and referred to a partner hospital. A midwife remains with her so that this decision is made early.'
where id = 'seed-faq-5';

update faqs set
  question = 'How long will I stay after the birth?',
  answer = 'After an uncomplicated delivery, most mothers are discharged within 24 to 48 hours, once feeding is established and both mother and baby have been examined. A postnatal clinic visit is then booked.'
where id = 'seed-faq-6';

insert into site_content (key, value) values (
  'homepage',
  '{"heroTag":"Divine Birth Midwifery Centre","heroTitleLine1":"Maternity care in","heroTitleEm":"Kahawa Wendani","heroSub":"Antenatal clinic, labour and delivery, postnatal care and child welfare. The centre is open 24 hours a day, including public holidays.","introEyebrow":"The centre","introTitle":"A licensed midwifery facility in Nairobi","introBody1":"Divine Birth Midwifery Centre is beside Alvo House, opposite PlayWay Academy in Kahawa Wendani. We look after women from the first antenatal visit through labour, the days after birth, and the child''s immunisation schedule.","introBody2":"Straightforward births are managed at the centre. If a woman needs theatre or specialist obstetric care, she is stabilised and referred to a partner hospital. Midwives are on duty on site at all hours — not on call from home.","introPull":"KMHFR licensed · Open 24 hours · Kahawa Wendani, Nairobi","aboutTitle":"About Divine Birth","aboutBody1":"The centre was established by midwife Diana to serve families in Kahawa Wendani and nearby estates: skilled maternity care without the cost of a large private hospital, and without the delays of an overcrowded public ward.","aboutBody2":"We provide antenatal care, antenatal classes, labour and delivery, postnatal clinic, child welfare and immunisation, ultrasound, laboratory services, family planning and doula support. SHA, SHIF and selected private insurance covers are accepted. Telephone 0794 444 141 to confirm what your cover includes before admission.","statementLine1":"In labour?","statementLine2":"Come to the centre. Call on the way."}'
)
on conflict (key) do update set
  value = excluded.value,
  updated_at = now()
where site_content.value like '%Natural. Safe.%'
   or site_content.value like '%birth story%'
   or site_content.value like '%leading midwifery%';
