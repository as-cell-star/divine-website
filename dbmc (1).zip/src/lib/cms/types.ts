export const SERVICE_OPTIONS = [
  "Antenatal Care",
  "Antenatal Classes & Exercises",
  "Birthing Services",
  "Doula Services",
  "Postnatal Clinic",
  "Maternal Wellness Programme",
  "Mental Health & Wellness",
  "Laboratory Services",
  "Ultrasound Services",
  "Family Planning",
  "Child Welfare Clinic",
  "General Consultation",
] as const;

export type ServiceOption = (typeof SERVICE_OPTIONS)[number];

export const PUBLIC_SERVICES = [
  {
    key: "Birthing Services" as const,
    img: "/images/photo-handover.jpg",
    alt: "A midwife placing a newborn into the mother’s arms",
    blurb: "Private birthing rooms with a midwife on duty throughout labour. Referral to hospital if theatre is needed.",
  },
  {
    key: "Antenatal Care" as const,
    img: "/images/photo-mother-baby.jpg",
    alt: "A mother with her newborn and a midwife",
    blurb: "Check-ups, screening and a birth plan through each trimester, with the same team where possible.",
  },
  {
    key: "Postnatal Clinic" as const,
    img: "/images/photo-swaddled.jpg",
    alt: "A midwife holding a swaddled newborn",
    blurb: "Recovery, breastfeeding support, newborn weight and a booked return visit after discharge.",
  },
  {
    key: "Child Welfare Clinic" as const,
    img: "/images/photo-twins.jpg",
    alt: "Two midwives each holding a newborn",
    blurb: "Immunisation, growth monitoring and developmental checks, with doses recorded on the child’s card.",
  },
  {
    key: "Ultrasound Services" as const,
    img: "/images/hero2.jpg",
    alt: "Care at Divine Birth Midwifery Centre",
    blurb: "Dating, anomaly and growth scans. Laboratory tests are taken on the same premises.",
  },
  {
    key: "Family Planning" as const,
    img: "/images/photo-midwife-blue.jpg",
    alt: "A midwife at the clinic",
    blurb: "Counselling and contraception after birth, in a private consultation.",
  },
] as const;

export type MediaKind = "gallery" | "hero" | "other";

export type MediaItem = {
  id: string;
  kind: MediaKind;
  url: string;
  alt: string;
  title: string;
  caption: string;
  category: string;
  sortOrder: number;
  createdAt: string;
};

export type HomepageContent = {
  heroTag: string;
  heroTitleLine1: string;
  heroTitleEm: string;
  heroSub: string;
  introEyebrow: string;
  introTitle: string;
  introBody1: string;
  introBody2: string;
  introPull: string;
  aboutTitle: string;
  aboutBody1: string;
  aboutBody2: string;
  statementLine1: string;
  statementLine2: string;
};

export type Testimonial = {
  id: string;
  quote: string;
  author: string;
  rating: number;
  sortOrder: number;
  published: boolean;
};

export type FaqItem = {
  id: string;
  question: string;
  answer: string;
  sortOrder: number;
  published: boolean;
};

export type Appointment = {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  notes: string;
  status: "pending" | "confirmed" | "cancelled";
  createdAt: string;
  cloudinaryUrl: string | null;
  emailStatus: "queued" | "sent" | "failed";
};

export type Inquiry = {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  service: string;
  message: string;
  status: "new" | "replied" | "archived";
  createdAt: string;
  cloudinaryUrl: string | null;
  emailStatus: "queued" | "sent" | "failed";
};

export type AdminStats = {
  pendingAppointments: number;
  newInquiries: number;
  galleryCount: number;
  heroCount: number;
};

export type SitePayload = {
  content: HomepageContent;
  hero: MediaItem[];
  gallery: MediaItem[];
  testimonials: Testimonial[];
  faqs: FaqItem[];
};

export type StaffMember = {
  id: string;
  name: string;
  email: string;
  createdAt: string;
};
