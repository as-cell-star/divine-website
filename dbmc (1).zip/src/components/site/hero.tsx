import { useEffect, useState } from "react";
import type { HomepageContent, MediaItem } from "@/lib/cms/types";
import { CLINIC } from "@/lib/cms/defaults";

export function Hero({ content, slides }: { content: HomepageContent; slides: MediaItem[] }) {
  const [index, setIndex] = useState(0);
  const photos = slides.length
    ? slides
    : [
        {
          id: "f",
          url: "/images/photo-midwife-newborn.jpg",
          alt: "A Divine Birth midwife holding a newborn",
          title: "",
          caption: "",
          category: "",
          kind: "hero" as const,
          sortOrder: 0,
          createdAt: "",
        },
      ];

  useEffect(() => {
    if (photos.length < 2) return;
    const t = window.setInterval(() => setIndex((i) => (i + 1) % photos.length), 7000);
    return () => window.clearInterval(t);
  }, [photos.length]);

  return (
    <section className="relative bg-plum-deep" aria-labelledby="heroHeading">
      <div className="relative h-[88svh] min-h-[520px] max-h-[820px]">
        {photos.map((s, i) => (
          <div key={s.id} className={i === index ? "hero-slide is-active" : "hero-slide"}>
            <img src={s.url} alt={s.alt || ""} width={1800} height={1200} fetchPriority={i === 0 ? "high" : "low"} />
          </div>
        ))}
        <div className="absolute inset-0 bg-gradient-to-r from-plum-deep/85 via-plum-deep/35 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-plum-deep/70 via-transparent to-plum-deep/20" />
        <div className="site-wrap relative z-10 flex h-full flex-col justify-end pb-12 pt-16 md:pb-16">
          <p className="text-[12px] font-medium tracking-[0.22em] text-gold uppercase">{content.heroTag}</p>
          <h1 id="heroHeading" className="font-display mt-3 max-w-xl text-[clamp(2.4rem,6vw,4.4rem)] leading-[1.02] text-white">
            {content.heroTitleLine1} {content.heroTitleEm}
          </h1>
          <p className="mt-5 max-w-md text-[16px] leading-relaxed text-white/80">{content.heroSub}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="/#booking" className="inline-flex h-12 items-center bg-teal px-6 text-sm font-semibold text-white hover:bg-teal-dark">
              Book a clinic visit
            </a>
            <a
              href={`tel:${CLINIC.phonePrimary}`}
              className="inline-flex h-12 items-center border border-white/40 px-6 text-sm font-semibold text-white hover:bg-white/10"
            >
              Call {CLINIC.phonePrimaryDisplay}
            </a>
          </div>
          <div className="mt-10 flex gap-1.5" role="tablist" aria-label="Photos">
            {photos.map((s, i) => (
              <button
                key={s.id}
                type="button"
                aria-label={`Photo ${i + 1}`}
                className={i === index ? "h-1 w-8 bg-gold" : "h-1 w-3 bg-white/40"}
                onClick={() => setIndex(i)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
