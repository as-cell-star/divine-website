import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { CLINIC } from "@/lib/cms/defaults";

const LINKS = [
  { href: "/#services", label: "Services" },
  { href: "/#about", label: "About" },
  { href: "/#testimonials", label: "Reviews" },
  { href: "/#faq", label: "Questions" },
  { href: "/#contact", label: "Find us" },
];

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      <header className="sticky top-0 z-50 bg-plum text-cream">
        <div className="h-0.5 bg-gold" />
        <div className="site-wrap flex h-[4.4rem] items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-3">
            <img src="/images/logo-emblem.png" alt="" width={42} height={42} className="size-[42px] object-contain" />
            <span className="leading-tight">
              <span className="block font-display text-[1.2rem] text-white">Divine Birth</span>
              <span className="block text-[10px] tracking-[0.16em] text-gold uppercase">Midwifery Centre</span>
            </span>
          </Link>
          <nav className="hidden items-center gap-7 lg:flex" aria-label="Main">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} className="text-[13px] text-cream/75 hover:text-white">
                {l.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <a href={`tel:${CLINIC.phonePrimary}`} className="hidden text-[13px] text-gold lg:inline">
              {CLINIC.phonePrimaryDisplay}
            </a>
            <a
              href="/#booking"
              className="inline-flex h-10 items-center bg-teal px-4 text-[13px] font-semibold text-white hover:bg-teal-dark"
            >
              Book appointment
            </a>
            <button
              type="button"
              className="inline-flex size-10 items-center justify-center lg:hidden"
              aria-label={open ? "Close menu" : "Open menu"}
              aria-expanded={open}
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X className="size-5" /> : <Menu className="size-5" />}
            </button>
          </div>
        </div>
      </header>
      {open ? (
        <div className="fixed inset-x-0 top-[4.65rem] bottom-0 z-50 bg-plum text-cream lg:hidden">
          <nav className="site-wrap flex flex-col py-6">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="border-b border-white/10 py-4 font-display text-3xl">
                {l.label}
              </a>
            ))}
            <a
              href="/#booking"
              onClick={() => setOpen(false)}
              className="mt-8 inline-flex h-12 items-center justify-center bg-teal font-semibold text-white"
            >
              Book a clinic visit
            </a>
          </nav>
        </div>
      ) : null}
    </>
  );
}
