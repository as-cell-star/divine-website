import { CLINIC } from "@/lib/cms/defaults";

export function SiteFooter() {
  return (
    <footer className="bg-plum-deep text-cream/65">
      <div className="h-0.5 bg-gold" />
      <div className="site-wrap grid gap-10 py-14 md:grid-cols-[1.5fr_1fr_1fr]">
        <div>
          <img src="/images/logo-lockup-light.png" alt={CLINIC.name} width={140} height={130} className="mb-4 w-28 object-contain" />
          <p className="font-display text-xl text-white">Divine Birth Midwifery Centre</p>
          <p className="mt-2 max-w-xs text-sm leading-relaxed">
            Licensed maternity facility in Kahawa Wendani, Nairobi. Open 24 hours.
          </p>
        </div>
        <div>
          <p className="mb-3 text-[11px] tracking-[0.16em] text-gold uppercase">The centre</p>
          <ul className="space-y-2 text-sm">
            <li><a href="/#services" className="hover:text-white">Services</a></li>
            <li><a href="/#booking" className="hover:text-white">Book an appointment</a></li>
            <li><a href="/#about" className="hover:text-white">About</a></li>
            <li><a href="/admin" className="hover:text-white">Staff login</a></li>
          </ul>
        </div>
        <div>
          <p className="mb-3 text-[11px] tracking-[0.16em] text-gold uppercase">Contact</p>
          <ul className="space-y-2 text-sm">
            <li><a href={`tel:${CLINIC.phonePrimary}`} className="hover:text-white">{CLINIC.phonePrimaryDisplay}</a></li>
            <li><a href={`mailto:${CLINIC.emailPrimary}`} className="hover:text-white">{CLINIC.emailPrimary}</a></li>
            <li>{CLINIC.addressLine1}<br />{CLINIC.addressLine2}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="site-wrap flex flex-col gap-2 py-4 text-[11px] text-white/35 sm:flex-row sm:justify-between">
          <span>© {new Date().getFullYear()} Divine Birth Midwifery Centre</span>
          <span>KMHFR licensed · Google {CLINIC.rating}</span>
        </div>
      </div>
    </footer>
  );
}
