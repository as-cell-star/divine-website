import { Clock, MapPin, Phone } from "lucide-react";
import { ActionBar } from "@/components/site/action-bar";
import { BookingForm } from "@/components/site/booking-form";
import { SiteFooter } from "@/components/site/footer";
import { SiteHeader } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { InquiryForm } from "@/components/site/inquiry-form";
import { CLINIC } from "@/lib/cms/defaults";
import { PUBLIC_SERVICES } from "@/lib/cms/types";
import type { SitePayload } from "@/lib/cms/types";

const STAGES = [
  { t: "Pregnancy", p: "Antenatal visits, classes and scans. Your file stays at this centre." },
  { t: "Labour", p: "A midwife remains with you. Hospital transfer is arranged if the birth needs theatre." },
  { t: "After birth", p: "Feeding, examination of mother and baby, and a postnatal appointment." },
  { t: "First year", p: "Immunisation and growth clinic. The next date is written on the card." },
];

export function HomePage({ data }: { data: SitePayload }) {
  const { content, hero, gallery, testimonials, faqs } = data;
  const featured = testimonials[0];
  const rest = testimonials.slice(1);

  return (
    <div className="bg-cream pb-16 md:pb-0">
      <SiteHeader />
      <Hero content={content} slides={hero} />

      <section className="bg-plum text-cream">
        <div className="site-wrap grid gap-6 py-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Hours", CLINIC.hours],
            ["Location", "Alvo House, Kahawa Wendani"],
            ["Telephone", CLINIC.phonePrimaryDisplay],
            ["Licence", "KMHFR registered maternity centre"],
          ].map(([k, v]) => (
            <div key={k}>
              <p className="text-[11px] tracking-[0.16em] text-gold uppercase">{k}</p>
              <p className="mt-1 text-sm text-white">{v}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="site-wrap grid items-center gap-14 py-20 md:grid-cols-2 md:py-28">
        <div>
          <p className="text-[12px] tracking-[0.2em] text-teal uppercase">{content.introEyebrow}</p>
          <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] leading-[1.08] text-ink">{content.introTitle}</h2>
          <p className="mt-6 text-[17px] leading-relaxed text-ink-mid">{content.introBody1}</p>
          <p className="mt-4 text-[17px] leading-relaxed text-ink-mid">{content.introBody2}</p>
        </div>
        <img
          src="/images/team-main.jpg"
          alt="Divine Birth midwives with newborns"
          className="h-[min(58vw,480px)] w-full object-cover"
        />
      </section>

      <section id="services" className="scroll-mt-24 bg-paper py-20 md:py-28">
        <div className="site-wrap grid gap-12 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="text-[12px] tracking-[0.2em] text-teal uppercase">Services</p>
            <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] text-ink">What the centre provides</h2>
            <p className="mt-4 max-w-lg text-[16px] text-ink-mid">
              These names match the appointment form. Telephone if you are already in labour.
            </p>
            <ol className="mt-10 divide-y divide-border border-y border-border">
              {PUBLIC_SERVICES.map((s, i) => (
                <li key={s.key} className="grid gap-2 py-5 sm:grid-cols-[2rem_1fr]">
                  <span className="text-sm text-gold">{String(i + 1).padStart(2, "0")}</span>
                  <div>
                    <h3 className="font-display text-xl text-ink">{s.key}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-ink-mid">{s.blurb}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
          <div className="grid gap-3">
            <img src="/images/photo-handover.jpg" alt={PUBLIC_SERVICES[0].alt} className="h-64 w-full object-cover lg:h-80" />
            <img src="/images/photo-mother-baby.jpg" alt={PUBLIC_SERVICES[1].alt} className="h-52 w-full object-cover" />
          </div>
        </div>
      </section>

      <section id="journey" className="scroll-mt-24 py-20 md:py-28">
        <div className="site-wrap">
          <p className="text-[12px] tracking-[0.2em] text-teal uppercase">From pregnancy to the first year</p>
          <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] text-ink">How care is organised</h2>
          <ol className="mt-12 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            {STAGES.map((s, i) => (
              <li key={s.t}>
                <p className="font-display text-4xl text-gold">{String(i + 1).padStart(2, "0")}</p>
                <h3 className="mt-3 font-display text-2xl text-ink">{s.t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-mid">{s.p}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="booking" className="scroll-mt-24 border-y border-border bg-paper py-20 md:py-28">
        <div className="site-wrap grid gap-12 lg:grid-cols-[0.78fr_1.22fr] lg:items-start">
          <div>
            <p className="text-[12px] tracking-[0.2em] text-teal uppercase">Appointments</p>
            <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] leading-tight text-ink">Book a clinic visit</h2>
            <p className="mt-4 max-w-sm text-[16px] leading-relaxed text-ink-mid">
              For antenatal, postnatal, scans and child clinic. We will telephone you to confirm the time.
            </p>
            <p className="mt-6 border-l-2 border-teal pl-4 text-sm leading-relaxed text-ink">
              If you are in labour, do not use this form. Call {CLINIC.phonePrimaryDisplay} and come to the centre.
            </p>
            <p className="mt-6 text-sm text-ink-soft">{CLINIC.hours}</p>
          </div>
          <div className="border border-border bg-cream p-2 md:p-4">
            <BookingForm />
          </div>
        </div>
      </section>

      <section id="about" className="scroll-mt-24">
        <img
          src="/images/hero4.jpg"
          alt="A Divine Birth midwife holding a newborn"
          className="h-[42vh] min-h-[280px] w-full object-cover object-[center_18%]"
        />
        <div className="site-wrap max-w-3xl py-16 md:py-24">
          <p className="text-[12px] tracking-[0.2em] text-teal uppercase">About</p>
          <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] leading-tight text-ink">{content.aboutTitle}</h2>
          <p className="mt-6 text-[17px] leading-relaxed text-ink-mid">{content.aboutBody1}</p>
          <p className="mt-4 text-[17px] leading-relaxed text-ink-mid">{content.aboutBody2}</p>
        </div>
      </section>

      <section id="gallery" className="scroll-mt-24 bg-plum-deep py-16 md:py-20">
        <div className="site-wrap mb-8">
          <h2 className="font-display text-4xl text-white">At the centre</h2>
          <p className="mt-2 text-sm text-white/60">Photographs from Divine Birth Midwifery Centre, Kahawa Wendani.</p>
        </div>
        <div className="site-wrap mosaic">
          {(gallery.length ? gallery : []).slice(0, 5).map((g) => (
            <figure key={g.id}>
              <img src={g.url} alt={g.alt || g.title} />
            </figure>
          ))}
        </div>
      </section>

      <section id="testimonials" className="scroll-mt-24 py-20 md:py-28">
        <div className="site-wrap">
          <p className="text-[12px] tracking-[0.2em] text-teal uppercase">Google reviews · {CLINIC.rating}</p>
          <h2 className="font-display mt-3 text-[clamp(2rem,4vw,3.1rem)] text-ink">What families have written</h2>
          {featured ? (
            <blockquote className="mt-12 max-w-3xl border-l-2 border-gold pl-6">
              <p className="font-display text-[clamp(1.5rem,3.2vw,2.3rem)] leading-snug text-ink">“{featured.quote}”</p>
              <footer className="mt-5 text-sm text-ink-soft">{featured.author}</footer>
            </blockquote>
          ) : null}
          {rest.length ? (
            <div className="mt-14 grid gap-10 md:grid-cols-2">
              {rest.map((t) => (
                <blockquote key={t.id}>
                  <p className="text-[16px] leading-relaxed text-ink-mid">“{t.quote}”</p>
                  <footer className="mt-3 text-sm text-ink-soft">{t.author}</footer>
                </blockquote>
              ))}
            </div>
          ) : null}
        </div>
      </section>

      <section className="bg-teal py-12 text-white md:py-14">
        <div className="site-wrap flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
          <div>
            <h2 className="font-display text-[clamp(1.8rem,3.4vw,2.6rem)] leading-tight">
              {content.statementLine1} {content.statementLine2}
            </h2>
            <p className="mt-2 text-sm text-white/85">Telephone {CLINIC.phonePrimaryDisplay}. The centre does not close.</p>
          </div>
          <a href={`tel:${CLINIC.phonePrimary}`} className="inline-flex h-12 items-center bg-plum px-6 text-sm font-semibold text-white">
            Call the centre
          </a>
        </div>
      </section>

      <section id="faq" className="scroll-mt-24 py-20 md:py-28">
        <div className="site-wrap grid gap-12 lg:grid-cols-[18rem_1fr]">
          <div>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-ink">Common questions</h2>
            <p className="mt-3 text-sm text-ink-mid">If your question is not listed, call or send a message below.</p>
          </div>
          <div className="divide-y divide-border border-y border-border">
            {faqs.map((f) => (
              <details key={f.id} className="faq-item group py-5">
                <summary className="flex cursor-pointer list-none justify-between gap-4 font-medium">
                  {f.question}
                  <span className="text-teal group-open:hidden">+</span>
                  <span className="hidden text-teal group-open:inline">–</span>
                </summary>
                <p className="mt-3 max-w-2xl text-sm leading-relaxed text-ink-mid">{f.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="scroll-mt-24 bg-paper py-20 md:py-28">
        <div className="site-wrap grid gap-14 lg:grid-cols-2">
          <div>
            <h2 className="font-display text-[clamp(2rem,4vw,3rem)] text-ink">Visit the centre</h2>
            <ul className="mt-7 space-y-3 text-[15px] text-ink-mid">
              <li className="flex gap-2">
                <MapPin className="mt-0.5 size-4 shrink-0 text-teal" />
                {CLINIC.addressLine1}, {CLINIC.addressLine2}
              </li>
              <li className="flex gap-2">
                <Clock className="mt-0.5 size-4 shrink-0 text-teal" />
                {CLINIC.hours}
              </li>
              <li className="flex gap-2">
                <Phone className="mt-0.5 size-4 shrink-0 text-teal" />
                <a href={`tel:${CLINIC.phonePrimary}`}>{CLINIC.phonePrimaryDisplay}</a>
                <span aria-hidden="true"> · </span>
                <a href={`tel:${CLINIC.phoneSecondary}`}>{CLINIC.phoneSecondaryDisplay}</a>
              </li>
            </ul>
            <p className="mt-4 text-sm">
              <a className="text-teal hover:underline" href={`mailto:${CLINIC.emailPrimary}`}>
                {CLINIC.emailPrimary}
              </a>
            </p>
            <iframe
              title="Map of Divine Birth Midwifery Centre"
              src={CLINIC.mapsEmbed}
              className="mt-8 h-64 w-full border border-border"
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div>
            <h3 className="font-display text-2xl text-ink">Send a message</h3>
            <p className="mt-2 mb-6 text-sm text-ink-mid">For clinic questions only. Labour cases should telephone.</p>
            <InquiryForm />
          </div>
        </div>
      </section>

      <section id="downloads" className="site-wrap flex flex-wrap items-center justify-between gap-4 py-12">
        <h2 className="font-display text-2xl text-ink">Brochures</h2>
        <div className="flex gap-3">
          <a href="/docs/Divine_Birth_Brochure.pdf" download className="border border-ink px-4 py-2 text-sm font-semibold">
            Brochure (PDF)
          </a>
          <a href="/docs/Divine_Birth_Pullup_Banner.pdf" download className="border border-ink px-4 py-2 text-sm font-semibold">
            Banner (PDF)
          </a>
        </div>
      </section>

      <SiteFooter />
      <ActionBar />
    </div>
  );
}
